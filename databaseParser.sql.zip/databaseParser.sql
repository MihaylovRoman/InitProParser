-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 20 2024 г., 19:00
-- Версия сервера: 10.8.4-MariaDB
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `databaseParser`
--

-- --------------------------------------------------------

--
-- Структура таблицы `card_info`
--

CREATE TABLE `card_info` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `name_org` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(33) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `card_info`
--

INSERT INTO `card_info` (`id`, `number`, `name_org`, `link`, `status`, `date`) VALUES
(1, 412, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"БАЛЧУГ-ПЕТРОЛЕУМ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/412', 'Идет прием заявок', '20.02.2024 09:45'),
(2, 411, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"РУСИНВЕСТ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/411', 'Идет прием заявок', '19.02.2024 16:45'),
(3, 410, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"РУСИНВЕСТ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/410', 'Идет прием заявок', '19.02.2024 16:40'),
(4, 409, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"РУСИНВЕСТ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/409', 'Идет прием заявок', '19.02.2024 16:34'),
(5, 408, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"РУСИНВЕСТ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/408', 'Идет прием заявок', '16.02.2024 15:12'),
(6, 406, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"РУСИНВЕСТ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/406', 'Идет прием заявок', '15.02.2024 15:17'),
(7, 405, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"БАЛЧУГ-ПЕТРОЛЕУМ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/405', 'Идет прием заявок', '15.02.2024 08:49'),
(8, 403, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"РУСИНВЕСТ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/403', 'Идет прием заявок', '13.02.2024 17:04'),
(9, 386, 'Павлов Дмитрий Евгеньевич', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/386', 'Идет прием заявок', '04.04.2024 17:00'),
(10, 385, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"БАЛЧУГ-ПЕТРОЛЕУМ\"', 'https://com.ru-trade24.ru/bidding/AnounsmentDetails/385', 'Идет прием заявок', '05.02.2024 11:02');

-- --------------------------------------------------------

--
-- Структура таблицы `docs`
--

CREATE TABLE `docs` (
  `id` int(11) NOT NULL,
  `name_doc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_card_info` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `docs`
--

INSERT INTO `docs` (`id`, `name_doc`, `link`, `id_card_info`) VALUES
(1, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/429', 1),
(2, 'Документация ЗК ЭФ проведение ЭПБ тех труб', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1201', 1),
(3, 'Перечень обьектов ТТ (приложение к ТЗ)', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1202', 1),
(4, 'Проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1203', 1),
(5, 'Техническое задание', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1204', 1),
(6, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/428', 2),
(7, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1197', 2),
(8, 'техническое задание', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1198', 2),
(9, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1199', 2),
(10, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/427', 3),
(11, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1194', 3),
(12, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1195', 3),
(13, 'техническое задание', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1196', 3),
(14, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/426', 4),
(15, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1191', 4),
(16, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1192', 4),
(17, 'техническое задание', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1193', 4),
(18, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/425', 5),
(19, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1188', 5),
(20, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1189', 5),
(21, 'приложения', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1190', 5),
(22, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/424', 6),
(23, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1186', 6),
(24, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1187', 6),
(25, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/423', 7),
(26, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1182', 7),
(27, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1183', 7),
(28, 'спецификация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1184', 7),
(29, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/421', 8),
(30, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1177', 8),
(31, 'техническое задание', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1178', 8),
(32, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1200', 8),
(33, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/406', 9),
(34, 'Проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1136', 9),
(35, 'Сообщение о проведении процедуры', 'https://com.ru-trade24.ru/bidding/GetTradeAnounsmentDoc/405', 10),
(36, 'проект договора', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1132', 10),
(37, 'техническое задание', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1133', 10),
(38, 'Прочее', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1134', 10),
(39, 'Прочее', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1135', 10),
(40, 'документация', 'https://com.ru-trade24.ru/bidding/GetTradeAttachment/1185', 10);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `card_info`
--
ALTER TABLE `card_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `docs`
--
ALTER TABLE `docs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_cardInfo` (`id_card_info`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `card_info`
--
ALTER TABLE `card_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `docs`
--
ALTER TABLE `docs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `docs`
--
ALTER TABLE `docs`
  ADD CONSTRAINT `docs_ibfk_1` FOREIGN KEY (`id_card_info`) REFERENCES `card_info` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
